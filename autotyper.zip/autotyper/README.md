# Autotyper AHK Script

**Autotyper** is an AutoHotkey script that allows you to type text automatically in Discord. It is especially useful for typing long messages or repeating phrases.

## Requirements

- AutoHotkey v2 (64-bit recommended)
- Discord

## Installation

1. Download and install AutoHotkey v2 from the [AutoHotkey website](https://autohotkey.com/download/).
2. Download the Autotyper script folder from [this link](https://community.spiceworks.com/scripts/show/366-auto-type-script).
3. Place the Autotyper script folder in a convenient location, such as your Desktop.

## Usage

1. Open Discord.
2. Press `CTRL` + `SHIFT` + `I` to open the Autotyper GUI.
3. Use the arrow keys or the mouse to select an item in the ListBox.
4. Press `Enter` to type the selected item.
5. Press `ESC` to close the Autotyper GUI.

## Uninstallation

1. Simply remove the Autotyper script folder.
2. (Optional) Uninstall AutoHotkey v2.

## Notes

- Autotyper is only active when Discord is in focus.
- Autotyper is a script, so it does not require any special permissions.
- Autotyper can be uninstalled at any time without any negative consequences.

## 64-bit vs. 32-bit AutoHotkey

Autotyper is designed to work with 64-bit AutoHotkey v2. This is because 32-bit AutoHotkey has a limited memory space, which can cause Autotyper to crash if you have a large number of items in the ListBox.

If you are using a 32-bit operating system, you can still use Autotyper, but you may need to reduce the number of items in the ListBox.

## Troubleshooting

If Autotyper is not working properly, please check the following:

- Make sure that you are using AutoHotkey v2.
- Make sure that Autotyper is running in the System Tray.
- Make sure that Discord is in focus.
- Make sure that you are pressing `CTRL` + `SHIFT` + `I` to open the Autotyper GUI.

If you are still having problems, please contact me for help.